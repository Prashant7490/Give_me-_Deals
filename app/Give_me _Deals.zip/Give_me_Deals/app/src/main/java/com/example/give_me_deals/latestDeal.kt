package com.example.give_me_deals

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class latestDeal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_latest_deal)
    }
}