package com.example.give_me_deals

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Resetpassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resetpassword)
    }
}