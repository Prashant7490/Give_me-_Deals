package com.example.give_me_deals.Data

data class PopularBusinessModel(
    var image1:String,
    var title:String,
    var businessName:String,
    var location:String,
)
