package com.example.give_me_deals.Firebase

data class UserSignUp (
    var fname : String = "",
    var lName: String = "",
    var Email: String = "",
    var Mobile: String = "",
    var Password:String = "",

)