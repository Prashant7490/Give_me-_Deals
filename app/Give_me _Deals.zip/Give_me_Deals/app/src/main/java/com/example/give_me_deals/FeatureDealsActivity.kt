package com.example.give_me_deals

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.give_me_deals.Data.FeatureDealModel
import com.example.give_me_deals.adapter.FeatureDealAdapter

class FeatureDealsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feature_deals)



    }
}