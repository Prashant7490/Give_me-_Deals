package com.example.give_me_deals.Data
data class DealsNearMeModel(
    var image1:String,
    var title:String,
    var discount:String,
    var businessName:String,
    var price:String,

)
