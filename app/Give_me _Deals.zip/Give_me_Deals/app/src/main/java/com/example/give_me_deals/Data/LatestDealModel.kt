package com.example.give_me_deals.Data

data class LatestDealModel (
        var image1:String,
        var title:String,
        var discount:String,
        var price:String,
    )