package com.example.give_me_deals.Data

data class FeatureDealModel(
    var image1:String,
    var title:String,
    var discount:String,
    var price:String,
)
